package abkrino.eg.baytaleaala.ui.internet;

public interface IOnBackPressed {
    boolean onBackPressed();

}
